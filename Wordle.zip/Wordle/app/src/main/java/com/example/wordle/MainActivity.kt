package com.example.wordle

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {

    private lateinit var wordToGuess: String
    private var guessesRemaining = 3
    private var currentGuessCount = 1

    private lateinit var guessInput: EditText
    private lateinit var guessButton: Button
    private lateinit var guess1Text: TextView
    private lateinit var guess1CheckText: TextView
    private lateinit var guess2Text: TextView
    private lateinit var guess2CheckText: TextView
    private lateinit var guess3Text: TextView
    private lateinit var guess3CheckText: TextView
    private lateinit var finalAnswerTextview: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        wordToGuess = FourLetterWordList.getRandomFourLetterWord()

        guessInput = findViewById(R.id.guess_input)
        guessButton = findViewById(R.id.guess_button)
        guess1Text = findViewById(R.id.guess1_text)
        guess1CheckText = findViewById(R.id.guess1_check_text)
        guess2Text = findViewById(R.id.guess2_text)
        guess2CheckText = findViewById(R.id.guess2_check_text)
        guess3Text = findViewById(R.id.guess3_text)
        guess3CheckText = findViewById(R.id.guess3_check_text)
        finalAnswerTextview = findViewById(R.id.final_answer_textview)

        guessButton.setOnClickListener {
            handleGuess()
        }
    }

    private fun handleGuess() {
        val guess = guessInput.text.toString().uppercase()
        guessInput.text.clear()

        if (guess.length != 4) {
            Toast.makeText(this, "Please enter a 4-letter word.", Toast.LENGTH_SHORT).show()
            return
        }

        val checkResult = checkGuess(guess)

        when (currentGuessCount) {
            1 -> {
                guess1Text.text = guess
                guess1CheckText.text = checkResult
            }
            2 -> {
                guess2Text.text = guess
                guess2CheckText.text = checkResult
            }
            3 -> {
                guess3Text.text = guess
                guess3CheckText.text = checkResult
            }
        }

        guessesRemaining--
        currentGuessCount++

        if (checkResult == "OOOO" || guessesRemaining == 0) {
            endGame(checkResult == "OOOO")
        }
    }

    private fun endGame(guessedCorrectly: Boolean) {
        guessButton.isEnabled = false
        guessInput.isEnabled = false
        finalAnswerTextview.text = wordToGuess
        finalAnswerTextview.visibility = View.VISIBLE

        if (guessedCorrectly) {
            Toast.makeText(this, "Congratulations! You guessed it!", Toast.LENGTH_LONG).show()
        } else {
            Toast.makeText(this, "Game Over. The word was $wordToGuess", Toast.LENGTH_LONG).show()
        }
    }

    /**
     * Parameters / Fields:
     *   guess : String - what the user entered as their guess
     *
     * Returns a String of 'O', '+', and 'X', where:
     *   'O' represents the right letter in the right place
     *   '+' represents the right letter in the wrong place
     *   'X' represents a letter not in the target word
     */
    private fun checkGuess(guess: String): String {
        var result = ""
        for (i in 0..3) {
            if (guess[i] == wordToGuess[i]) {
                result += "O"
            } else if (guess[i] in wordToGuess) {
                result += "+"
            } else {
                result += "X"
            }
        }
        return result
    }
}
